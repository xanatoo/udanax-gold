/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef COMDTCTP_IXX
#define COMDTCTP_IXX


#include "shephx.hxx"



/* ************************************************************************ *
 * 
 *                    Class DoneEvent 
 *
 * ************************************************************************ */


/* creation */
/* triggering */
/* creation */



/* ************************************************************************ *
 * 
 *                    Class FilledEvent 
 *
 * ************************************************************************ */


/* creation */
/* triggering */
/* creation */



/* ************************************************************************ *
 * 
 *                    Class GrabbedEvent 
 *
 * ************************************************************************ */


/* creation */
/* triggering */
/* creation */



/* ************************************************************************ *
 * 
 *                    Class RangeFilledEvent 
 *
 * ************************************************************************ */


/* creation */
/* creation */
/* triggering */



/* ************************************************************************ *
 * 
 *                    Class ReleasedEvent 
 *
 * ************************************************************************ */


/* creation */
/* creation */
/* triggering */



/* ************************************************************************ *
 * 
 *                    Class RevisedEvent 
 *
 * ************************************************************************ */


/* creation */
/* creation */
/* triggering */


#endif /* COMDTCTP_IXX */

